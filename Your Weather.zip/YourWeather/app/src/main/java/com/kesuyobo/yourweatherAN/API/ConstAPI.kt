package com.kesuyobo.yourweatherAN.API

object ConstAPI {
    val apikey = "b1f2da7e1b84465bb97113524242801"
}