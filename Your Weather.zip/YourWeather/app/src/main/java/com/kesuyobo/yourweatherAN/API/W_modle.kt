package com.kesuyobo.yourweatherAN.API

data class W_modle(
    val current: Current,
    val location: Location
)