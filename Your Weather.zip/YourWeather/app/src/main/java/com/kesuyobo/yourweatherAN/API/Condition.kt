package com.kesuyobo.yourweatherAN.API

data class Condition(
    val code: String,
    val icon: String,
    val text: String
)